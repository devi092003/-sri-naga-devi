class car:
    def cmpany(self,name):
        l= ['toyota','mercedes','suzuki']
        if name in l:
            print("welcome to",name)
    def model(self,name):
        d={'toyota':['fortuner','innova'],'mercedes':['BMW'],'suzuki':['swift','Alto']}
        if name in d:
            ptint(d[name])
    def price(self,name,m):
        print("you have selected",m)
        prices_list={'fortuner':7500000,'innova':5000000,'BMW':10000000,'swift':3000000,'Alto':1000000} 
        if m in price_list:
            car_price ==price_list[m]
            gst = 0.1*car_price 
            insurance = 100000 
            final_price = car_price+gst+insurance 
            print("final price",final_price)
n = input("enter the car company:")
c =car()
c.company(n)
c.model(n)
m = input("enter model of car:")
c.price(n,m)
            
            