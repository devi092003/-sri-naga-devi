n=1234
rev=432
rev=0
while n>0:
    d=n%10
    rev=rev*10+d 
    n=n//10
print(rev)    
