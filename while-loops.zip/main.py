n=12467
while n>0:
    digit=n%10 
    print(digit)
    n=n//10